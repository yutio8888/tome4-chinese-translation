# B timing protocol (frozen 2026-09-25 before the first sample)

- Input: root = /workspace/tome4-projection-analysis-20260925, treeish = 35cae04614c8710b0287b6d7870f80bdd7c374ea.
- Harness: tools/orchestration/profile_projection.py --no-profile (identical file in both tool trees).
  baseline = .artifacts/i18n/review-tool-speed-20260925/oracle-b/tools (4 impl files == 35cae046, rest == candidate)
  candidate = tools/ in this worktree.
- Env: I18N_PROJECTION_CACHE and I18N_PROJECTION_CACHE_TRACE unset (harness also removes them and asserts no cache events).
- Each sample: fresh process, `timeout -k 10s 900s`, serial, no other tests/projections running, no tools/ edits while any sample runs.
- Order: feasibility B1, C1; if correct and clearly faster, then C2, B2, B3, C3 (alternating).
- Correctness per pair: 8 identity fields equal, progress dict equal (and progress_sha256), head unchanged, queue invariant.
- Acceptance (frozen by host, not relaxed): median(C wall_s) <= 0.80 * median(B wall_s);
  median(C peak_self_rss_kib) <= 1.20 * median(B peak_self_rss_kib); also report every sample and max C RSS.
