# B 实施批准：单次投影内逐行成功校验复用

host已核验validate_catalog_files源码及行重复计数，热点与该函数语义相关，准许在既有SCOPE内实现。不引入跨进程/跨提交持久缓存。A成果保留，baseline-B/为本轮修改前副本，原baseline/继续是整个任务最终diff基线。

1. 仅复用当前投影生命周期内成功校验的完整行，作用域关闭/异常时清空；非投影入口仍可独立完整校验。完整字节相等是命中必要条件，manifest依赖要么进入身份，要么每次重查，不能仅以revision identity或hash信任另一行。
2. 保留JSONL严格字节/键/格式、不合法行、错误标签/顺序和异常类型；所有catalog级排序、唯一性、logical重复、计数、守恒、全文件digest、规则schema/policy、source/term绑定检查仍每次执行。缓存不得把可变row共享给可能修改它的消费者导致污染；证明已有intern与新复用的所有权语义。失败验证不可被记为成功，其他正常调用不受影响。
3. 保守控制内存，观测实际峰值。不要因相同行命中跳过依赖当前manifest的校验。文件内/跨catalog正反例差分测试，并覆盖same revision different bytes、manifest单字段变化、异常后下一投影、嵌套或不同root作用域、无缓存路径；新增循环有短超时终止探针。
4. 测量方法先冻结：用同一harness、同一35cae046、同一工作树、串行新进程cache off、无cProfile，原算法与候选的内容/类型/digests/progress一致，timeout -k10s 900s。不比较423秒profile与无profile候选。先各一次可行性样本；确认正确且显著获益后再各补两次，交替顺序，3样本中位数。运行时禁止编辑tools源文件。可用私有实验开关或baseline-B副本作为原算法oracle，但不能污染全局生产API/无故保留开关。
5. 本轮预定目标：完整重放中位墙钟减少至少20%，峰值RSS增长不超过20%。这些是host在B实施前冻结的取舍门槛，不因结果调松。达不到时报告/保留可审查差异，host裁决是否缩小或撤销B；不能假称通过。主生产目录不变，不初始化工作树生产queue，profile/benchmark只读Git证据。
6. focused与相关ledger组on/off串行验证；完整17门禁/构建host最终统一执行。修订结果报告记录A+B、精确测量边界、内存、所有限制。在此前scope允许的profile_projection.py或新test_projection_optimization.py提供需要的最小差分/计时支持即可；如确实需要新文件，先报告不要越界。

本轮不改surface契约，不修无关问题。不要修改task/reviews、主工作区、Git配置；不stage/commit/merge/push、不child。host会在验收后执行用户授权的合入和恢复审核。
