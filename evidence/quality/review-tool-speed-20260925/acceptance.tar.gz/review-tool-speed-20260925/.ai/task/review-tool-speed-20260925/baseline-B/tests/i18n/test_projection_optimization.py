"""Profile harness for one cache-off projection: exact identity, no side effects."""
from __future__ import annotations

import json
import os
import pstats
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from tests.i18n import test_production_review_v2_lite_migration as migration_tests
from tools.i18nlib import production_review_v2_lite_queue as queue
from tools.i18nlib import projection_cache as cache
from tools.orchestration import benchmark_projection as base

REPO = Path(__file__).resolve().parents[2]
HARNESS = REPO / "tools/orchestration/profile_projection.py"


class ProfileHarnessTests(migration_tests.MigrationFixture):
    _publish_surface_batch = migration_tests.MigrationTests._publish_surface_batch

    def setUp(self):
        super().setUp()
        self._publish_surface_batch(repair=False, entry_index=1, batch_name="done")
        self.out = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.out, True)

    def _run(self, output: Path, *, check: bool = True) -> subprocess.CompletedProcess:
        # The parent shell exports the switch: the harness must still not touch the cache.
        environment = {**os.environ, cache.MODE_ENV: "on", cache.TRACE_ENV: "1"}
        return subprocess.run([sys.executable, "-B", str(HARNESS), "--root", str(self.root),
                               "--treeish", "HEAD", "--output-dir", str(output), "--top", "5"],
                              cwd=REPO, env=environment, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, text=True, timeout=300, check=check)

    def test_one_profiled_replay_matches_the_oracle_and_writes_nothing_else(self):
        before = subprocess.check_output(["git", "status", "--porcelain", "--ignored"],
                                         cwd=self.root, text=True)
        with cache.disabled():
            oracle = queue._projection(self.root, "HEAD", progress={})
        output = self.out / "profile"
        result = self._run(output)
        self.assertNotIn("projection-cache:", result.stderr)
        report = json.loads((output / "summary.json").read_text(encoding="utf-8"))
        self.assertEqual(report["kind"], "projection_profile")
        self.assertEqual(report["identity"]["head"], oracle[0])
        self.assertEqual(report["identity"]["entries_d"], base._digest(list(oracle[2])))
        self.assertEqual(report["identity"]["overrides_d"], base._digest(oracle[3]))
        self.assertEqual(report["identity"]["reconciliation_d"], base._digest(oracle[4]))
        self.assertTrue(report["head_unchanged"])
        self.assertTrue(report["queue_invariance"]["unchanged"])
        self.assertEqual(len(report["profile"]["top_tottime"]), 5)
        self.assertEqual(sorted(path.name for path in output.iterdir()),
                         ["profile.pstats", "summary.json"])
        self.assertGreater(len(pstats.Stats(str(output / "profile.pstats")).stats), 0)
        self.assertFalse(cache.cache_directory(self.root).exists())
        self.assertEqual(subprocess.check_output(["git", "status", "--porcelain", "--ignored"],
                                                 cwd=self.root, text=True), before)

    def test_refuses_a_used_output_directory_and_an_active_checkpoint(self):
        used = self.out / "used"
        used.mkdir()
        (used / "keep").write_text("prior\n")
        result = self._run(used, check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual((used / "keep").read_text(), "prior\n")
        self.assertEqual([path.name for path in used.iterdir()], ["keep"])

        queue.checkpoint_path(self.root).write_text("{}")
        result = self._run(self.out / "active", check=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("active queue checkpoint", result.stderr)
        self.assertFalse((self.out / "active" / "summary.json").exists())


if __name__ == "__main__":
    unittest.main()
