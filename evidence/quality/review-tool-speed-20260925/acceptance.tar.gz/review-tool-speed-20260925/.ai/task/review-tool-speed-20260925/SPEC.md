# 审核工具耗时优化

mode: implement
change_class: infrastructure
review_contracts: code_legacy_v1

用户授权：在独立工作树进一步减少工具耗时，保持正确性和使用流畅性。继续使用已指定的 Opus 5.5 作为执行者；主工作树与第278批安全暂停保持不变。本任务不提交、不合并、不推送，不自动开始第279批。

基线35cae046。已有未跟踪 docs/review278-isolated-analysis-20260925.md 是只读分析成果，保留，不改。SCOPE列明内容唯一写入范围。EXECUTOR只在 /workspace/tome4-projection-analysis-20260925 工作；主工作区绝不写。派生实验输出仅本工作树.artifacts/i18n/review-tool-speed-20260925/；不改真实证据、译文、术语、handoff、AGENTS、角色或审核契约。Git工作树共享对象库，不改共享Git配置、不清理/prune对象。测试写临时fixture。

## A：必须完成的稳定性提速

1. 修复外部 I18N_PROJECTION_CACHE=on 导致门禁测试失败的集成缺陷。隔离分析已复现3tests在off通过、on失败；父on子off的完整ledger组532tests通过。
2. 在 fixture 初始化前明确测试默认状态，恢复环境；既有计数测试必须不被磁盘缓存干扰，cache tests仍明确测试on/off/真实CLI。直接unittest入口和tools/test_groups.py入口均覆盖。禁止删除失败测试或宽松化计数以掩盖问题。
3. 门禁子进程环境策略须与回执绑定一致；不要全局清除父进程环境从而让prepare-evidence重放，不要伪造回执或修改历史receipt/validator要求绕过验证。选择最小实现：若fixture显式隔离足以保持完整继承及现有binding，则优先不引入新的gate环境格式；若确需子进程环境策略，须兼容历史回放并绑定实际策略/环境，完整验证首尾不漂移。实现前说明取舍于结果报告。
4. 真实prepare-evidence（隔离fixture）在父on下：历史读取可命中，全部现有业务/SQLite/checkpoint校验继续；门禁失败保留adjudicated，修复环境后单独重试可成功，不重复导入裁决；原错误继续暴露。测试应触达真实调用链，而非只检查env字典。
5. 不减少门禁/构建/源码审计，不缓存gate receipt，不合并跨HEAD的finalize/rebuild。生产缓存默认off保持，显式on可以顺畅贯穿正常批次链，不要求用户手动unset补跑。

## B：用证据选择后续计算优化

同一dispatch在A之后进行一次有界函数级完整投影剖析，固定本工作树baseline HEAD、cache off，timeout -k 10s 900s，运行只读投影，不建立本树生产queue或active batch。捕获输出/progress摘要、主要调用耗时与CPU热点。历史catalog已有按blob identity去重和行intern，不能重复宣称已有收益。允许新增小型profile harness，不改旧benchmark验收阈值。
本dispatch先交付A实现和B剖析及一个最小可行优化候选，host确认热点和范围后继续新executor实施B；不要无证据引入内容级持久缓存。跨提交缓存、surface契约重写、行政闭合事务重构不在本次范围。

## 验证与交付

EXECUTOR运行风险相关focused tests，并在父on/off两种环境运行相关生产ledger组（串行，有超时）；其他大门禁交host统一。host最终在on/off执行适用完整门禁并独立双模型复审。若本工作树doctor因来源配置缺失而失败，报告实际配置需求，不写主工作树。
基准不能混用实现指纹冒充受控比较。B实际优化后才冻结同一输入的基线/候选计时边界，结果完全一致、错误路径一致；接受性能目标应由剖析得出，不承诺50%。目录/解析循环变化须有界终止测试。
写docs/review-tool-speed-results-20260925.md说明问题、实现、测量、限制、回执兼容、命令可用性与后续B建议；最末交付列变更、tests、未解决。切勿以“等待后台通知”作为完成回复；若后台仍在运行则继续收齐结果再交付。

## 后续用户授权覆盖
用户明确要求：验收通过后提交并合入主开发区，验证集成及队列同步，然后让主开发区空闲Opus5.5继续推进审核。由host执行集成和恢复；EXECUTOR仍禁止自行提交、合并、推送或恢复批次。原先任务不合并/不启动279的限制据此在验收之后由host解除。当前实现阶段仍保持生产暂停。
