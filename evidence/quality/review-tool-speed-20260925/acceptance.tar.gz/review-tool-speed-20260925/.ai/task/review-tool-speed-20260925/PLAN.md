1. EXECUTOR实现A环境隔离，验证父缓存on/off都正常，进行B一次只读剖析。
2. ORCHESTRATOR核验、归档executor，根据真实热点选择最小计算优化；必要fresh executor继续，保留A。
3. 冻结完整候选及基线diff，正常和高级reviewer独立审查，确认问题集中修复。
4. 宿主on/off适用门禁、性能正确性对比和生产状态不变检查；全部child归档，DONE_VERIFIED，交付工作树成果。保持主线暂停，不自动合并或发布。
